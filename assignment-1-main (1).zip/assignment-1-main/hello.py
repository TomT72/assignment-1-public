from flask import Flask,render_template,request
app = Flask(__name__)
@app.route('/')
@app.route('/home_page')
def home_page():
    user = {'username': 'Tom72'}
    return render_template('index.html', user=user)


@app.route('/login_reg')
def login_reg():
    user = {'username': 'Tom72'}
    return render_template('login_reg.html', user=user) 



@app.route('/dashboard_page')
def dashboard_page():
    user = {'username': 'Tom72'}
    return render_template('dashboard_page.html', user=user) 


@app.route('/add_transaction_page')
def add_transaction_page():
    user = {'username': 'Tom72'}
    return render_template('add_transaction_page.html', user=user) 


@app.route('/edit_transaction_page')
def edit_transaction_page():
    user = {'username': 'Tom72'}
    return render_template('edit_transaction_page.html', user=user)


@app.route('/manage_categories_page')
def manage_categories_page():
    user = {'username': 'Tom72'}
    return render_template('manage_categories_page.html', user=user)


@app.route('/reports_page')
def reports_page():
    user = {'username': 'Tom72'}
    return render_template('reports_page.html', user=user)


@app.route('/login')
def login():
    user = {'username': 'Tom72'}
    return render_template('login.html', user=user) 


@app.route('/addtransaction', methods=['GET', 'POST'])
def add_transaction():
    if request.method == 'POST':
        for key, value in request.form.items():
            print(f'{key}: {value}')
    return render_template('add_transaction_page.html')

@app.route('/edit transaction', methods=['GET', 'POST'])
def edit_transaction():
    if request.method == 'POST':
        for key, value in request.form.items():
            print(f'{key}: {value}')
    return render_template('edit_transaction_page.html')